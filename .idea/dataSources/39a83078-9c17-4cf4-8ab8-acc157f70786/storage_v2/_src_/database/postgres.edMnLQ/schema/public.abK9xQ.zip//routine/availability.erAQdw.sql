create function availability() returns trigger
    language plpgsql
as
$$
    DECLARE
        tmp_availability integer;
    BEGIN
        tmp_availability = ((select sum(good_amount)
            from goods_in_delivery
            where good_id = NEW.good_id
            group by good_id
            ) - (select sum(good_amount)
            from goods_in_supply
            where good_id = NEW.good_id
            group by good_id));

    IF tmp_availability IS NULL THEN
        update goods
        set availability = 0;
    end if;
    IF tmp_availability IS NOT NULL THEN
    set availability =
           tmp_availability;
    end if;
        RETURN tmp_availability;
END;
$$;

alter function availability() owner to postgres;


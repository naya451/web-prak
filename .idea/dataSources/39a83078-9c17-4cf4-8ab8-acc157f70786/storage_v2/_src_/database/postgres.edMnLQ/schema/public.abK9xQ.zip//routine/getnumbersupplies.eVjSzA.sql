create function getnumbersupplies(id integer) returns integer
    language plpgsql
as
$$
begin
    return (SELECT COUNT(*)
            FROM Supplies
            WHERE Supplies.seller_id = id);
END;
$$;

alter function getnumbersupplies(integer) owner to postgres;


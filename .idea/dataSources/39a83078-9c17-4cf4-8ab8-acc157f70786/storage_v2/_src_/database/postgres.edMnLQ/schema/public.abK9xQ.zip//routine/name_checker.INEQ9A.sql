create function name_checker() returns trigger
    language plpgsql
as
$$
begin
    update deliveries set Buyer_name = (select buyer_name from buyers where buyer_id = NEW.buyer_id);
    return NEW;
END;
$$;

alter function name_checker() owner to postgres;


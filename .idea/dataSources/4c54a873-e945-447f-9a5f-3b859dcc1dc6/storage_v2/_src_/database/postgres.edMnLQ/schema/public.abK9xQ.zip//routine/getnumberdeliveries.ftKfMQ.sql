create function getnumberdeliveries(id integer) returns integer
    language plpgsql
as
$$
begin
    return (SELECT COUNT(*)
            FROM Deliveries
            WHERE Deliveries.delivery_id = id);
END;
$$;

alter function getnumberdeliveries(integer) owner to postgres;


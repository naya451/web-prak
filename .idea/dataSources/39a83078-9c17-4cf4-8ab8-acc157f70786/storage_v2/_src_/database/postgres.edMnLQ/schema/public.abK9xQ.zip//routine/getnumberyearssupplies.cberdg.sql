create function getnumberyearssupplies(id integer) returns integer
    language plpgsql
as
$$
begin
    return (SELECT COUNT(*)
            FROM Supplies
            WHERE Supplies.seller_id = id
              AND Supplies.supply_date_time >= current_timestamp - interval '1 year');
END;
$$;

alter function getnumberyearssupplies(integer) owner to postgres;


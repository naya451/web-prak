create function getnumberofgoodsindelivery(id integer) returns integer
    language plpgsql
as
$$
begin
    return (SELECT COUNT(*)
            FROM goods_in_delivery
            WHERE goods_in_delivery.delivery_id = id);
END;
$$;

alter function getnumberofgoodsindelivery(integer) owner to postgres;


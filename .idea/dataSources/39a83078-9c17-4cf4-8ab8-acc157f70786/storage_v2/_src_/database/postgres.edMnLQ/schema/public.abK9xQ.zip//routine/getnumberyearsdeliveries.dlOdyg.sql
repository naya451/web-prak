create function getnumberyearsdeliveries(id integer) returns integer
    language plpgsql
as
$$
begin
    return (SELECT COUNT(*)
            FROM Deliveries
            WHERE Deliveries.buyer_id = id
              AND Deliveries.delivery_date_time >= current_timestamp - interval '1 year');
END;
$$;

alter function getnumberyearsdeliveries(integer) owner to postgres;


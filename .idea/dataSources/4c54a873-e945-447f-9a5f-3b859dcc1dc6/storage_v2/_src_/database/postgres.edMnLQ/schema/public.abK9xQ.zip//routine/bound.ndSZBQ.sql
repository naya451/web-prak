create function bound() returns trigger
    language plpgsql
as
$$
begin
    update deliveries set Buyer_name = (select buyer_name from buyers where buyer_id = NEW.buyer_id);
    return NEW;
END;
$$;

alter function bound() owner to postgres;


create function getdeliveriesnumber(id integer) returns integer
    language plpgsql
as
$$
begin
    return (SELECT COUNT(*)
            FROM Deliveries
            WHERE Deliveries.buyer_id = id);
END;
$$;

alter function getdeliveriesnumber(integer) owner to postgres;


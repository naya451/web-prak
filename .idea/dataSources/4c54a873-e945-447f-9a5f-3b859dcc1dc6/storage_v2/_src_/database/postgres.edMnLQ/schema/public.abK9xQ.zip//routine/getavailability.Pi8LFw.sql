create function getavailability(id integer) returns integer
    language plpgsql
as
$$
begin
    return (SELECT COUNT(*)
            FROM warehouse_condition
            WHERE warehouse_condition.good_id = id);
END;
$$;

alter function getavailability(integer) owner to postgres;


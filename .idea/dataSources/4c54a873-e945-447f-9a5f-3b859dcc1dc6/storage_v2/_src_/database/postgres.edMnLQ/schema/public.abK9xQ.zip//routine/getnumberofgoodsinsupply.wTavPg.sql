create function getnumberofgoodsinsupply(id integer) returns integer
    language plpgsql
as
$$
begin
    return (SELECT COUNT(*)
            FROM goods_in_supply
            WHERE goods_in_supply.supply_id = id);
END;
$$;

alter function getnumberofgoodsinsupply(integer) owner to postgres;

